# Breathe

Breathe is a flutter app made that was made as a part of the YEAH! Hackathon.

Breathe helps people to find oxygen cylinder vendors around them. Vendors can register them in this app and alott cylinders for selling. Potential users can then get the vendors marked on a Google Map in the app, making them easy to either call them or book the cylinders in the app itself. The vendors get an update on their dashboard when someone books their cylinders.
