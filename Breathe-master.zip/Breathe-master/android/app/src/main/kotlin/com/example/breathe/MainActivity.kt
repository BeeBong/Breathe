package com.example.breathe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
